import StudentInterestForm from "../../components/StudentInterestForm";

const Home = () => {
  return (
    <div>
      <StudentInterestForm />
    </div>
  );
};

export default Home;
