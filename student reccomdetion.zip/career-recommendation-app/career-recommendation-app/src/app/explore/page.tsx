import ExploreSection from "../../components/ExploreSection";

const ExplorePage = () => {
  return (
    <div>
      <ExploreSection />
    </div>
  );
};

export default ExplorePage;
