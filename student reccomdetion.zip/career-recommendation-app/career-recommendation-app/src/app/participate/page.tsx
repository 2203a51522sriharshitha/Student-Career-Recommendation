import CompetitionsSection from "../../components/CompetitionsSection";

const CompetitionsPage = () => {
  return (
    <div>
      <CompetitionsSection />
    </div>
  );
};

export default CompetitionsPage;
